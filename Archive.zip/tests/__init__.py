"""
Tests package for agentic_browser.
"""
